﻿namespace $ext_safeprojectname$.Infrastructure
{
    public class Class1
    {

    }
}
