﻿namespace $ext_safeprojectname$.Application
{
    public class Class1
    {

    }
}
