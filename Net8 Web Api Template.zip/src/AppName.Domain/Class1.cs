﻿namespace $ext_safeprojectname$.Domain
{
    public class Class1
    {

    }
}
